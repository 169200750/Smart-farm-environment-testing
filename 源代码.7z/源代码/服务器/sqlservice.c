#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sqlite3.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>

int mySubstr(char *buf, char *s, int l)
{
    int len = strlen(buf), idx = 0��i = 0;;
    for (i = l; i <= len; i++)
    {
        if (buf[i] >= '0' && buf[i] <= '9' && i < len)
        {
            s[idx++] = buf[i];
        }
        else if(idx>0)
        {
                break;
        }
    }
    return i;
}

char flg;
int myfunc(void *p, int argc, char **argv, char **argv_name)
{
        flg = *argv[0];
//      printf("huidiao:%c\n",flg);
        return 0;
}

void sqlselect()
{
         sqlite3 *db;
     char *err = 0;
     int ret = 0;
     int empty = 1;

     // �����ݿ�
     ret = sqlite3_open("/var/www/xuedao", &db);
     if (ret != SQLITE_OK)
     {
         printf("sqlite3 open error \n");
         exit(1);
     }
     // ��ѯ
     char str[100] = "SELECT * FROM wcyled";
     ret = sqlite3_exec(db, str, myfunc, &empty, &err);
     if (ret != SQLITE_OK)
     {
         printf("sqlite3 selsect error \n");
         sqlite3_close(db);
         exit(1);
     }
          sqlite3_close(db);
}

void sqlinsert(int idx,char *temp, char *humi)
{
  sqlite3 *db;
  char *err =0;
  int re =0,empty = 1;

  // �����ݿ�
  re = sqlite3_open("/var/www/xuedao",&db);
  if(re !=SQLITE_OK)
  {
    printf("sqlite3 open error\n");
    exit(1);
        sqlite3_close(db);
  }

  // ������
  char sql[1024]={0};
  re = sprintf(sql,"insert into wcy values(%d,%s,%s)",idx,temp,humi);
  re = sqlite3_exec(db,sql,NULL,NULL,&err);
  if(re !=SQLITE_OK)
  {
    printf("sqlite3 insert error\n");
    exit(1);
        sqlite3_close(db);
  }

  sqlite3_close(db);
}

void deltable()
{
  sqlite3 *db;

  char *err = 0;
  int re = 0;

  // �����ݿ�
  re = sqlite3_open("/var/www/xuedao",&db);

  // ���
  re = sqlite3_exec(db,"delete from wcy",NULL,NULL,&err);
  if(re !=SQLITE_OK)
  {
    printf("sqlite3 delete error\n");
    exit(1);
        sqlite3_close(db);
  }
  sqlite3_close(db);
}

int main()
{
        int sock = socket(AF_INET,SOCK_DGRAM,0);
        if(sock < 0) perror("socket");
        struct sockaddr_in dst;
        dst.sin_family = AF_INET;
        dst.sin_port = htons(8226);
        dst.sin_addr.s_addr = INADDR_ANY;

        // ��
        int ret = bind(sock,(struct sockaddr*) &dst, sizeof(dst));
        if(ret < 0) perror("bind");

        // ����
        struct sockaddr_in src;
        int rcv_len = 0;
        int id = 0;

        //���
        deltable();

        while(1)
        {
                char buf[1024] = {0};
                int i = 0;
                for(i = 0; i < 5e8; i++);
            ret = recvfrom(sock,buf,sizeof(buf),0,(struct sockaddr*) & dst, &rcv_len);
            if(ret < 0) perror("recvfrom");
                if(buf[0] == '0' || buf[0] == '1' || strlen(buf) < 19) continue;
            char temp[10]={0};
            char humi[10]={0};
            int ne = 0;
            ne = mySubstr(buf,temp,ne);
            ne = mySubstr(buf,humi,ne);
                if(strlen(humi) <= 1 || strlen(temp) <= 1) continue;
            printf("i:%d t:%s h:%s\n",id,temp,humi);

                sqlinsert(id,temp,humi);

                sqlselect();

                sendto(sock,&flg,1,0,(struct sockaddr*)&dst,rcv_len);
                //printf("flg=%c\n",flg);
            id++;
        }
        close(sock);
}
