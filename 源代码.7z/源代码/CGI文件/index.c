#include <stdio.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <sqlite3.h>

 void show_head()
 {
     printf("Content-type: text/html\n\n");
     printf("<html>\n");
     printf("<head>\n");
     printf("<meta http-equiv=\"refresh\" content=\"1\">\n");
     printf("<title>Group2</title>\n");
     printf("<style type=\"text/css\">\n");
     printf("tr {font-size: 85px; font-weight: bold;font-family: ΢���ź�;text-align: center}\n");
     printf("button { font-size: 85px; font-weight: bold;font-family: ΢���ź�; background-color:#F5DEB3;\n");
     printf("display: inline-block; cursor: pointer; transition-duration: 0.5s; border-style:none}\n");
     printf(".button2:hover{box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);}\n");
     printf("div {position: relative; margin:auto; text-align:cneter;}\n");
     printf("</style>\n");
     printf("</head>\n");
     printf("<body bgcolor=\"#888888\">\n");
     printf("<div>\n");
     printf("<center>\n");
     //printf("<h1>�ǻ�ũ�����ϵͳ</h1>\n");
 }

 void show_end()
 {
     printf("</center>\n");
     printf("</div>\n");
     printf("</body>");
     printf("</html>\n");
 }

 void show_time(char *str)
 {
     time_t timer0;
     timer0= time(NULL);
     struct tm* tt = localtime(&timer0);
     int y = tt->tm_year + 1900,m = tt->tm_mon + 1, d = tt->tm_mday;
     int h = tt->tm_hour, mi = tt->tm_min, s = tt->tm_sec;
     sprintf(str,"%02d-%02d-%02d %02d:%02d:%02d",y,m,d,h,mi,s);
 }

 int myfunc(void *p, int argc, char **argv, char **argv_name)
 {
     show_head();

 // ������ϸ����
     printf("<table border=\"0\" cellspacing=\"0\" width=\"100%\" height=\"100%\">\n");

     printf("<tr style=\"background-color:#FFCC33;\">\n");
     printf("<td colspan = '2'>�ǻ�ũ���������ϵͳ</td>\n");
     printf("</tr>\n");

     printf("<tr style=\"background-color:#CCFF66;\">\n");
     printf("<td>��&nbsp;&nbsp;�ȣ�</td>\n");
     printf("<td>%s</td>\n",argv[1]);
     printf("</tr>\n");

     printf("<tr style=\"background-color:#CCFF99;\">\n");
     printf("<td>ʪ&nbsp;&nbsp;�ȣ�</td>\n");
     printf("<td>%s</td>\n",argv[2]);
     printf("</tr>\n");

     char str[100] = {0};
     show_time(str);

     printf("<tr style=\"background-color:#FFFF99;\">\n");
     printf("<td>ʱ&nbsp;&nbsp;�䣺</td>\n");
     printf("<td>%s</td>\n",str);
     printf("</tr>\n");

     printf("<tr style=\"background-color:#FFF8DC;\">");
     printf("<td colspan=\"2\">\n");
     printf("<button class=\"button2\" onclick=\"window.location.href='group2_wcy_open.cgi'\">��&nbsp;&nbsp;��</button>\n");
     printf("<button class=\"button2\"  onclick=\"window.location.href='group2_wcy_close.cgi'\">��&nbsp;&nbsp;��</button>\n");
     printf("</td>\n");
     printf("</tr>\n");
     printf("</table>\n");
 // �������ݽ���

     show_end();
     return 0;
 }

 int main(int argc, char *argv[])
 {
     sqlite3 *db;
     char *err = 0;
     int ret = 0;
     int empty = 1;

     // �����ݿ�
     ret = sqlite3_open("/var/www/xuedao", &db);
     if (ret != SQLITE_OK)
     {
         printf("sqlite3 open error \n");
         exit(1);
     }
     // ��ѯ
     char str[100] = "SELECT * FROM wcy WHERE ID = (SELECT MAX(ID) FROM wcy);";
     ret = sqlite3_exec(db, str, myfunc, &empty, &err);
     if (ret != SQLITE_OK)
     {
         printf("sqlite3 exec error \n");
         sqlite3_close(db);
         exit(1);
     }

     sqlite3_close(db);
     return 0;
}
