// open LED��ҳ

#include <stdio.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <sqlite3.h>

 void htmlHead()
 {
     printf("Content-type: text/html\n\n");
     printf("<html>\n");
     printf("<head>\n");

     printf("<title>Group2</title>\n");
     printf("<style type=\"text/css\">\n");
     printf("tr {font-size: 85px; font-weight: bold;font-family: ΢���ź�;text-align: center; border-style:none;}\n");
     printf("button { font-size: 85px; font-weight: bold;font-family: ΢���ź�; background-color:#F5DEB3;\n");
     printf("display: inline-block; cursor: pointer; transition-duration: 0.5s; border-style:none}\n");
     printf(".button2:hover{box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);}\n");


     printf("div {position: relative; margin:auto; text-align:cneter;}\n");
     printf("</style>\n");
     printf("</head>\n");
     printf("<body bgcolor=\"#888888\">\n");
     printf("<div>\n");
     printf("<center>\n");
     //printf("<h1>�ǻ�ũ�����LED����״̬</h1>\n");
 }

 void htmlEnd()
 {
     printf("</center>\n");
     printf("</div>\n");
     printf("</body>");
     printf("</html>\n");
 }

 void htmlTime(char *str)
 {
     time_t timer0;
     timer0= time(NULL);
     struct tm* tt = localtime(&timer0);
     int y = tt->tm_year + 1900,m = tt->tm_mon + 1, d = tt->tm_mday;
     int h = tt->tm_hour, mi = tt->tm_min, s = tt->tm_sec;
     sprintf(str,"%02d-%02d-%02d %02d:%02d:%02d",y,m,d,h,mi,s);
 }


 void htmlShow()
 {
        htmlHead();

 // ������ϸ����
     //printf("<table border=\"0\" cellspacing=\"10\">\n");
         printf("<table border=\"0\" cellspacing=\"0\" width=\"100%\" height=\"100%\">\n");

     printf("<tr style=\"background-color:#FFCC33;\">\n");
     printf("<td colspan='2'>�ǻ�ũ���������ϵͳ</td>\n");
     printf("</tr>\n");

     printf("<tr style=\"background-color:#CCFF99;\">\n");
     printf("<td>LED״̬��</td>\n");
     printf("<td>LED�ѿ���</td>\n");
     printf("</tr>\n");

     char str[100] = {0};
     htmlTime(str);

     printf("<tr style=\"background-color:#FFFF99;\">\n");
     printf("<td>��&nbsp;&nbsp;��&nbsp;&nbsp;ʱ&nbsp;&nbsp;�䣺</td>\n");
     printf("<td>%s</td>\n",str);
     printf("</tr>\n");

     printf("<tr style=\"background-color:#FFF8DC;\">\n");
     printf("<td colspan=\"2\">\n");
     printf("<button class=\"button2\" onclick=\"window.location.href='19html.cgi'\">��&nbsp;&nbsp;ҳ</button>\n");
     printf("<button class=\"button2\" onclick=\"window.location.href='group2_wcy_close.cgi'\">��&nbsp;&nbsp;��</button>\n");
     printf("</td>\n");
     printf("</tr>\n");

     printf("</table>\n");
 // �������ݽ���

     htmlEnd();
 }

 // �ص�����
 int myfunc(void *p, int argc, char **argv, char **argv_name)
 {
         htmlShow();
     return 0;
 }

 void delTable()
{
    sqlite3 *db;

    char *err = 0;
    int re = 0;

    // �����ݿ�
    re = sqlite3_open("/var/www/xuedao", &db);

    // ���
    re = sqlite3_exec(db, "delete from wcyled;", NULL, NULL, &err);
    if (re != SQLITE_OK)
    {
        printf("sqlite3 delete error\n");
        sqlite3_close(db);
        exit(1);
    }
    sqlite3_close(db);
}

void insTable()
{
    sqlite3 *db;
    char *err = 0;
    int re = 0, empty = 1;

    // �����ݿ�
    re = sqlite3_open("/var/www/xuedao", &db);
    if (re != SQLITE_OK)
    {
        printf("sqlite3 open error\n");
        sqlite3_close(db);
        exit(1);
    }

        int idx = 1;
    // ������
    char sql[1024] = {0};
    sprintf(sql, "insert into wcyled values(%d)",idx);
    re = sqlite3_exec(db, sql, NULL, NULL, &err);
    if (re != SQLITE_OK)
    {
        printf("sqlite3 insert error\n");
        sqlite3_close(db);
        exit(1);
    }
    sqlite3_close(db);
}

// ���
 void selTable()
 {
         sqlite3 *db;
     char *err = 0;
     int ret = 0;
     int empty = 1;

     // �����ݿ�
     ret = sqlite3_open("/var/www/xuedao", &db);
     if (ret != SQLITE_OK)
     {
         printf("sqlite3 open error \n");
         exit(1);
     }
     // ��ѯ
     char str[100] = "SELECT * FROM wcyled;";
     ret = sqlite3_exec(db, str, myfunc, &empty, &err);
     if (ret != SQLITE_OK)
     {
         printf("sqlite3 exec error \n");
         sqlite3_close(db);
         exit(1);
     }
 }

 int main(int argc, char *argv[])
 {
         delTable();

         insTable();

         selTable();

     return 0;
}