#include <stm32l1xx.h>
extern void RCC_Configuration(void);
