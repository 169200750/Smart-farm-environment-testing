#ifndef __DELAY_H
#define __DELAY_H 			   
#include <stm32l1xx.h>
#define u8 unsigned char 
#define u16 unsigned short 
#define u32 unsigned int 
void delay_init(void);
void delay_ms(u16 nms);
void Delay(u16 nms);
#endif





























