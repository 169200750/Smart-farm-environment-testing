#include "main.h"
#include "led.h"
#include "usart.h"
#include "dht11.h"
#include "delay.h"
#include "BC20.h"
#include <stdio.h>
#include <string.h>

extern char cardid[40];

int main(void)
{
	u8 temp = 0, humi = 0;
	char len[20] = {0};
	int ret = 0;
	
	my_LED_Init(); // ���
	delay_init();
	uart1_init(115200);
	//uart2_init(115200);
	//uart3_init(115200);
	delay_ms(2000);
	
	while(DHT11_Init());
	printf("=======DHT11 init complete========\n");
	//while(BC20_Init()) {};
	printf("=======DHT11 init complete========\n");
	while(1)
	{
		char data[50] = {0};
		DHT11_Read_Data(&temp, &humi);
		printf("temp : %d humi : %d\n",temp, humi);
		
		// ret��¼���ֽ���
		ret = sprintf(data, "temp=%d,humi=%d",temp, humi);
		sprintf(len, "%d", ret );
		//BC20_Senddata((uint8_t *)len, (uint8_t *)data);//������
		//Delay(1000);
    //BC20_RECData();
    Delay(1500);
		
	}
	
}
